 # -*- coding: utf-8 -*-

import asyncio
import json
import constants
import utils
import wqb
from AlphaMapper import AlphaMapper

class Simulator:
    def __init__(self,  wqbs: wqb.WQBSession, concurrency: int = 8, batch_size:int=30, db_path:str="./db"):
        """
        Args:
            wqbs: wqb.WQBSession
            concurrency: 并发数
            batch_size: 批量回测的alpha数量, 即多少个回测完成后更新一次数据库
            db_path: 数据库路径
        """
        self.wqbs = wqbs
        self.concurrency = concurrency
        self.batch_size = batch_size
        self.mapper = AlphaMapper(db_path)

    def simulate(self):
        """回测"""
        count = self.mapper.count(f'status = "{constants.ALPHA_STATUS_INIT}"')
        print(f'🎯 共有{count}个alpha待回测...')
        
        total_success = 0
        total_failed = 0
        page = 0
        
        while True:
            alphas = self.mapper.get_alphas(page_size=self.batch_size, page=page)
            total = len(alphas)
            if total == 0:
                break
                
            print(f'\n📊 第{page+1}批次: {total}个alpha')
            print('=' * 60)
            
            failed_count = self.do_simulate(alphas)
            success_count = total - failed_count
            
            total_success += success_count
            total_failed += failed_count
            
            print(f'\n✅ 第{page+1}批次结果:')
            print(f'   🟢 成功: {success_count} 个')
            print(f'   🔴 失败: {failed_count} 个')
            print(f'   📈 成功率: {success_count/total*100:.1f}%')
            
            # 显示总体进度
            completed = total_success + total_failed
            progress = completed / count * 100
            print(f'\n📈 总体进度: {completed}/{count} ({progress:.1f}%)')
            print(f'   🟢 总成功: {total_success} 个')
            print(f'   🔴 总失败: {total_failed} 个')
            print(f'   📊 总成功率: {total_success/completed*100:.1f}%' if completed > 0 else '   📊 总成功率: 0.0%')
            
            page += 1
            
        print(f'\n🎉 回测完成!')
        print('=' * 60)
        print(f'📊 最终统计:')
        print(f'   🟢 总成功: {total_success} 个')
        print(f'   🔴 总失败: {total_failed} 个')
        print(f'   📈 总成功率: {total_success/count*100:.1f}%')
        print(f'   🎯 总处理: {count} 个')
    
    def do_simulate(self, alphas:list, alpha_ids:list = None)->int:
        """回测
        return: 
            list of success alpha, list of failed alpha
        """
        # 构造数据
        alpha_list = []
        for alpha in alphas:
            settings = alpha['settings'].replace("'", '"')
            alpha_list.append({
                'type': alpha['type'],
                'settings': json.loads(settings),
                'regular': alpha['regular']
            })

        failed_count = 0
        success_count = 0
        
        print(f'🚀 开始回测...')
        
        # 逐个回测，这样可以更好地控制过程
        for idx, alpha_data in enumerate(alpha_list, start=1):
            try:
                print(f'\n🔄 回测 [{idx}/{len(alpha_list)}]: {alpha_data["regular"][:50]}...')
                
                # 调用simulate方法
                resp = asyncio.run(
                    self.wqbs.simulate(
                        alpha_data,
                        max_tries=range(600),
                        on_nolocation=lambda vars: print(f'⚠️  无位置信息: {vars["target"]}'),
                        log=f'{self.__class__}#simulate_{idx}'
                    )
                )
                
                # 检查响应
                if resp is None:
                    failed_count += 1
                    print(f'❌ 回测失败 [{idx}/{len(alpha_list)}]: 响应为空')
                    continue
                
                # 检查HTTP状态码
                if hasattr(resp, 'status_code'):
                    if resp.status_code != 200:
                        failed_count += 1
                        print(f'❌ 回测失败 [{idx}/{len(alpha_list)}]: HTTP状态码 {resp.status_code}')
                        continue
                
                # 尝试解析JSON响应
                try:
                    data = resp.json()
                except Exception as json_error:
                    failed_count += 1
                    print(f'❌ JSON解析失败 [{idx}/{len(alpha_list)}]: {json_error}')
                    continue
                
                # 检查响应数据是否包含必要字段
                if 'alpha' not in data or 'id' not in data:
                    failed_count += 1
                    print(f'❌ 响应数据不完整 [{idx}/{len(alpha_list)}]: 缺少必要字段')
                    continue
                
                # 更新数据库 - 第一阶段：保存location_id和alpha_id
                try:
                    hash_id = alphas[idx-1]['hash_id']
                    if alpha_ids is not None:
                        alpha_ids.append(data['alpha'])
                        
                    self.mapper.updateByHashId(hash_id, {
                        'location_id': data['id'],
                        'alpha_id': data['alpha'],
                        'status': constants.ALPHA_STATUS_SIMUATED
                    })
                    
                    print(f'✅ 回测提交成功: Alpha ID = {data["alpha"]}')
                    
                    # 第二阶段：获取回测结果
                    try:
                        result_resp = asyncio.run(self.wqbs.locate_alpha(alpha_id=data['alpha']))
                        
                        if result_resp is None or result_resp.status_code != 200:
                            print(f'❌ 获取Alpha {data["alpha"]} 结果失败')
                        else:
                            result_data = result_resp.json()
                            
                            # 提取回测指标
                            is_data = result_data.get('is', {})
                            results = {
                                'sharpe': is_data.get('sharpe', 0),
                                'fitness': is_data.get('fitness', 0),
                                'turnover': is_data.get('turnover', 0),
                                'margin': is_data.get('margin', 0),
                                'returns': is_data.get('returns', 0),
                                'drawdown': is_data.get('drawdown', 0),
                                'longCount': is_data.get('longCount', 0),
                                'shortCount': is_data.get('shortCount', 0),
                                'grade': result_data.get('grade', ''),
                                'status': constants.ALPHA_STATUS_SYNC
                            }
                            
                            print(f'📊 Alpha {data["alpha"]} 指标: Sharpe={results["sharpe"]:.4f}, Fitness={results["fitness"]:.4f}, Turnover={results["turnover"]:.4f}, Grade={results["grade"]}')
                            
                            # 更新数据库 - 保存回测结果
                            self.mapper.updateByHashId(hash_id, results)
                            
                    except Exception as result_error:
                        print(f'❌ 获取回测结果失败: {result_error}')
                    
                    success_count += 1
                    
                except Exception as db_error:
                    failed_count += 1
                    print(f'❌ 数据库更新失败: {db_error}')
                
            except KeyboardInterrupt:
                print(f'\n⚠️  回测被用户中断')
                failed_count += len(alpha_list) - idx + 1
                break
            except Exception as e:
                failed_count += 1
                print(f'❌ 回测异常: {e}')
        
        print(f'\n📊 本批次回测统计:')
        print(f'   🟢 成功: {success_count} 个')
        print(f'   🔴 失败: {failed_count} 个')
        print(f'   📈 成功率: {success_count/len(alpha_list)*100:.1f}%')
        
        # 显示数据库状态
        remaining_count = self.mapper.count(f'status = "{constants.ALPHA_STATUS_INIT}"')
        simulated_count = self.mapper.count(f'status = "{constants.ALPHA_STATUS_SIMUATED}"')
        synced_count = self.mapper.count(f'status = "{constants.ALPHA_STATUS_SYNC}"')
        print(f'\n💾 数据库状态:')
        print(f'   📋 待回测: {remaining_count} 个')
        print(f'   🔄 已提交: {simulated_count} 个')
        print(f'   ✅ 已完成: {synced_count} 个')
            
        return failed_count